import React, { useState } from 'react';
import { Upload, CheckCircle, AlertCircle } from 'lucide-react';

const DocumentUpload: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [documents, setDocuments] = useState({
    aadhar: { status: 'pending' },
    pan: { status: 'pending' },
    income: { status: 'pending' }
  });

  const handleUpload = (type: 'aadhar' | 'pan' | 'income') => {
    setDocuments(prev => ({
      ...prev,
      [type]: { status: 'uploaded' }
    }));

    if (Object.values(documents).every(doc => doc.status === 'uploaded')) {
      setTimeout(onComplete, 1000);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="text-blue-800 font-medium">Document Requirements</h3>
        <p className="text-blue-600 text-sm mt-1">
          Please ensure all documents are clear and legible. We accept JPG, PNG, or PDF formats.
        </p>
      </div>

      <div className="grid gap-4">
        {[
          { type: 'aadhar', label: 'Aadhaar Card' },
          { type: 'pan', label: 'PAN Card' },
          { type: 'income', label: 'Income Proof' }
        ].map(({ type, label }) => (
          <div key={type} className="border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-gray-900">{label}</h4>
                <p className="text-sm text-gray-500">Upload a clear copy</p>
              </div>
              <button
                onClick={() => handleUpload(type as any)}
                className="flex items-center px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                {documents[type as keyof typeof documents].status === 'uploaded' ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : (
                  <Upload className="h-5 w-5 text-gray-600" />
                )}
                <span className="ml-2">
                  {documents[type as keyof typeof documents].status === 'uploaded' ? 'Uploaded' : 'Upload'}
                </span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default DocumentUpload;