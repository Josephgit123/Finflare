import React, { useState } from 'react';
import { Video, Mic, Play, Square } from 'lucide-react';

const VideoChat: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);

  const questions = [
    "Could you please introduce yourself and state the purpose of your loan application?",
    "What is your current employment status and monthly income?",
    "How much loan amount are you looking for and what's the preferred tenure?"
  ];

  const handleRecord = () => {
    setIsRecording(!isRecording);
    if (isRecording) {
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(prev => prev + 1);
      } else {
        onComplete();
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden relative">
        {currentQuestion === 0 && (
          <img 
            src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e"
            alt="AI Branch Manager"
            className="w-full h-full object-cover"
          />
        )}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
          <p className="text-white text-lg">{questions[currentQuestion]}</p>
        </div>
      </div>

      <div className="flex justify-center space-x-4">
        <button
          onClick={handleRecord}
          className={`flex items-center px-6 py-3 rounded-full ${
            isRecording 
              ? 'bg-red-500 hover:bg-red-600' 
              : 'bg-indigo-600 hover:bg-indigo-700'
          } text-white transition-colors`}
        >
          {isRecording ? (
            <>
              <Square className="h-5 w-5 mr-2" />
              Stop Recording
            </>
          ) : (
            <>
              <Play className="h-5 w-5 mr-2" />
              Start Recording
            </>
          )}
        </button>
      </div>

      <div className="mt-4">
        <div className="h-1 bg-gray-200 rounded-full">
          <div 
            className="h-1 bg-indigo-600 rounded-full transition-all duration-300"
            style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
          />
        </div>
        <p className="text-sm text-gray-500 mt-2">
          Question {currentQuestion + 1} of {questions.length}
        </p>
      </div>
    </div>
  );
}

export default VideoChat;