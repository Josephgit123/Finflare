import React from 'react';
import { CheckCircle, XCircle, RefreshCw } from 'lucide-react';

interface LoanStatusProps {
  status: 'pending' | 'approved' | 'rejected' | 'more-info';
}

const LoanStatus: React.FC<LoanStatusProps> = ({ status }) => {
  const statusConfig = {
    pending: {
      icon: RefreshCw,
      title: 'Processing Your Application',
      color: 'text-blue-600',
      bg: 'bg-blue-50',
      border: 'border-blue-200',
      message: 'Please wait while we review your application...'
    },
    approved: {
      icon: CheckCircle,
      title: 'Congratulations! Loan Approved',
      color: 'text-green-600',
      bg: 'bg-green-50',
      border: 'border-green-200',
      message: 'Your loan has been approved. Our representative will contact you shortly.'
    },
    rejected: {
      icon: XCircle,
      title: 'Application Not Approved',
      color: 'text-red-600',
      bg: 'bg-red-50',
      border: 'border-red-200',
      message: 'Unfortunately, we cannot approve your loan at this time.'
    },
    'more-info': {
      icon: RefreshCw,
      title: 'Additional Information Required',
      color: 'text-yellow-600',
      bg: 'bg-yellow-50',
      border: 'border-yellow-200',
      message: 'We need some additional information to process your application.'
    }
  };

  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <div className={`${config.bg} border ${config.border} rounded-lg p-6 text-center`}>
      <Icon className={`h-12 w-12 ${config.color} mx-auto mb-4`} />
      <h2 className={`text-2xl font-bold ${config.color} mb-2`}>{config.title}</h2>
      <p className="text-gray-600">{config.message}</p>

      <div className="mt-8 space-y-4">
        <div className="bg-white rounded-lg p-4 shadow-sm">
          <h3 className="font-medium text-gray-900">Application Summary</h3>
          <div className="mt-2 space-y-2 text-sm text-gray-600">
            <div className="flex justify-between">
              <span>Application ID</span>
              <span className="font-medium">FGP-2024-001</span>
            </div>
            <div className="flex justify-between">
              <span>Requested Amount</span>
              <span className="font-medium">₹5,00,000</span>
            </div>
            <div className="flex justify-between">
              <span>Tenure</span>
              <span className="font-medium">36 months</span>
            </div>
          </div>
        </div>

        <button className="w-full py-3 px-4 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
          View Detailed Report
        </button>
      </div>
    </div>
  );
}

export default LoanStatus;