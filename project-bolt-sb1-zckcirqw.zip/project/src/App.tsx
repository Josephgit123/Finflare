import React, { useState } from 'react';
import { Camera as VideoCamera, Upload, CheckCircle, XCircle, RefreshCw, UserCircle2 } from 'lucide-react';
import VideoChat from './components/VideoChat';
import DocumentUpload from './components/DocumentUpload';
import LoanStatus from './components/LoanStatus';

function App() {
  const [step, setStep] = useState(1);
  const [loanStatus, setLoanStatus] = useState<'pending' | 'approved' | 'rejected' | 'more-info'>('pending');

  const handleNextStep = () => {
    setStep(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <UserCircle2 className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">FinanceGPT</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-500">AI Branch Manager</span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-white rounded-2xl shadow-xl p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome to FinanceGPT</h1>
            <p className="text-gray-600">Your AI-powered virtual branch manager</p>
          </div>

          <div className="space-y-8">
            {/* Progress Steps */}
            <div className="flex justify-between items-center mb-8">
              {[1, 2, 3].map((num) => (
                <div key={num} className="flex items-center">
                  <div className={`rounded-full h-10 w-10 flex items-center justify-center ${
                    step >= num ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-600'
                  }`}>
                    {num === 1 ? <VideoCamera className="h-5 w-5" /> :
                     num === 2 ? <Upload className="h-5 w-5" /> :
                     <CheckCircle className="h-5 w-5" />}
                  </div>
                  {num < 3 && (
                    <div className={`w-24 h-1 ${step > num ? 'bg-indigo-600' : 'bg-gray-200'}`} />
                  )}
                </div>
              ))}
            </div>

            {/* Step Content */}
            {step === 1 && <VideoChat onComplete={handleNextStep} />}
            {step === 2 && <DocumentUpload onComplete={handleNextStep} />}
            {step === 3 && <LoanStatus status={loanStatus} />}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;